# Tiramisu wallet API client

This is a Python client for tiramisu wallet API that allows for programmatic trading, minting, sending and receiving of Taproot Assets.

